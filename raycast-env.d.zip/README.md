# Dictionary for Windows

A simple extension to look up words