# Dictionary for Windows Changelog

## [Initial Version] - {PR_MERGE_DATE}